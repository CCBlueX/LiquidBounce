import{j as n}from"./index-f7941b89.js";function r(){return n.jsx("div",{children:"HUD"})}export{r as Component};
